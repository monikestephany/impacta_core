﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DesenvolvimentoWeb.WebAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DesenvolvimentoWeb.WebAPI.Controllers
{
    [Produces("application/json")]
    [Route("api/Pagamentos")]
    public class PagamentosController : Controller
    {
        private readonly PagamentoContext _context;

        public PagamentosController(PagamentoContext context)
        {
            this._context = context;
        }

        //Actions
        [HttpGet]
        public IEnumerable<Pagamento> GetPagamentos()
        {
            return _context.Pagamentos.ToList();
        }

        [HttpGet("{id}", Name = "GetPagamento")]
        public IActionResult GetById(long id)
        {
            var item = _context.Pagamentos.FirstOrDefault(p => p.Id == id);
            if(item == null)
            {
                return NotFound();
            }
            return new ObjectResult(item);
        }

        [HttpPost]
        public IActionResult PostPagamento([FromBody] Pagamento pagto)
        {
            var pagamento = _context.Pagamentos
                .FirstOrDefault(p => p.IdEvento == pagto.IdEvento &&
                    p.Cpf == pagto.Cpf);

            if(pagamento == null)
            {
                //status = 1: adicionado na fatura
                //status = 2: pagamento da fatura
                pagto.Status = 1;
                _context.Add<Pagamento>(pagto);
                _context.SaveChanges();
                return CreatedAtRoute("GetPagamento", new { id = pagto.Id });
            }
            else
            {
                return BadRequest();
            }
        }
    }
}