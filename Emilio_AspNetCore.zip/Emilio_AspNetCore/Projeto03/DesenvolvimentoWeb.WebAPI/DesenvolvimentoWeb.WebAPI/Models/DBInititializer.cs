﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DesenvolvimentoWeb.WebAPI.Models
{
    public static class DBInititializer
    {
        public static void Initialize(PagamentoContext context)
        {
            context.Database.EnsureCreated();
        }
    }
}
