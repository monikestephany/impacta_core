﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DesenvolvimentoWeb.Projeto01.Models;
using Microsoft.AspNetCore.Mvc;

namespace DesenvolvimentoWeb.Projeto01.Controllers
{
    public class InicioController : Controller
    {
        //primeiro action: string
        public string MostrarTexto()
        {
            return "<h1>Conceitos do MVC</h1>";
        }

        public FileResult MostrarPdf()
        {
            return File("~/Arquivos/Desenvolvimento Web com Asp.Net Core - Rev03.pdf", "application/pdf");
        }

        public IActionResult MostrarImagem()
        {
            return File("~/Arquivos/comida.jpg", "image/jpeg");
        }

        public ViewResult MostrarConteudo()
        {
            return View();
        }

        public IActionResult Index()
        {
            return View();
        }

        //trabalhando com a classe Produto
        //1. Criando um objeto e apresentando para o usuário
        public IActionResult MostrarProduto()
        {
            Produto produto = new Produto()
            {
                Codigo = 100, Descricao = "Bicicleta", Preco = 1000
            };
            return View("MostrarProduto", produto);
        }

        //2. Lista de Produtos - List
        public IActionResult ListarProdutos1()
        {
            List<Produto> produtos = new List<Produto>()
            {
                new Produto{ Codigo = 10, Descricao = "Caneta", Preco = 10},
                new Produto{ Codigo = 20, Descricao = "Celular", Preco = 899 }
            };

            return View("ListarProdutos1", produtos);
        }

        //3. Lista de Produtos - HashSet
        public IActionResult ListarProdutos2()
        {
            HashSet<Produto> produtos = new HashSet<Produto>()
            {
                new Produto{ Codigo = 30, Descricao = "Camisa", Preco = 99 },
                new Produto{ Codigo = 40, Descricao = "Boné", Preco = 45 },
                new Produto{ Codigo = 50, Descricao = "Tenis", Preco = 399 }
            };


            return View("ListarProdutos1", produtos);
        }

        //4. Formulário de Cadastro de Produtos
        [HttpGet]
        public IActionResult CadastroProduto()
        {
            return View();
        }

        [HttpPost]
        public IActionResult CadastroProduto(Produto produto)
        {
            if(produto.Codigo <= 100)
            {
                ModelState.AddModelError("Codigo", "O código deve ser maior que 100");
            }
            if (!ModelState.IsValid)
            {
                return View();
            }

            return View("MostrarProduto", produto);
        }
    }
}